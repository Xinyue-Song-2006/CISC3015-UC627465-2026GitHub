Run: pip install -r requirements.txt
Then: python DV0101EN-Final-Assign-Part-2-Questions.py
Open http://127.0.0.1:8051
