"""CISC3015 Assignment 02 - Final Project Part 2.
Author: SONG XINYUE (UC627465)
AI use disclosure: OpenAI Codex was used to assist with code drafting, debugging, and presentation. The author reviewed the implementation, verified calculations, and accepts responsibility for the submitted work.
"""
from pathlib import Path
import os
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

df = pd.read_csv(Path(__file__).with_name("historical_automobile_sales.csv"))
DEFAULT_REPORT = os.getenv("REPORT_DEFAULT", "Recession Period Statistics")
DEFAULT_YEAR = int(os.getenv("YEAR_DEFAULT", "2020"))
MONTH_ORDER = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
app = Dash(__name__)
app.layout = html.Div([
    html.H1("Automobile Sales Statistics Dashboard", style={"textAlign":"center","color":"#503D36","fontSize":24}),
    html.P("Author: SONG XINYUE | Student ID: UC627465", style={"textAlign":"center"}),
    html.Div([
        html.Label("Select Statistics:"),
        dcc.Dropdown(id="dropdown-statistics", options=[
            {"label":"Yearly Statistics","value":"Yearly Statistics"},
            {"label":"Recession Period Statistics","value":"Recession Period Statistics"}], value=DEFAULT_REPORT, clearable=False),
        html.Label("Select Year:"),
        dcc.Dropdown(id="select-year", options=[{"label":str(y),"value":y} for y in sorted(df.Year.unique())], value=DEFAULT_YEAR, clearable=False)
    ], style={"maxWidth":"500px","margin":"0 auto 12px"}),
    html.Div(id="output-container", className="chart-grid"),
    html.P("AI disclosure: OpenAI Codex assisted with drafting and debugging; all calculations and outputs were reviewed by the author.", style={"fontSize":"12px","color":"#555"})
], style={"maxWidth":"1400px","margin":"auto","fontFamily":"Arial"})

@app.callback(Output("select-year","disabled"), Input("dropdown-statistics","value"))
def update_year_dropdown(selected_statistics):
    return selected_statistics == "Recession Period Statistics"

@app.callback(Output("output-container","children"), Input("dropdown-statistics","value"), Input("select-year","value"))
def update_output_container(selected_statistics, input_year):
    if selected_statistics == "Recession Period Statistics":
        d = df[df["Recession"] == 1]
        yearly = d.groupby("Year",as_index=False)["Automobile_Sales"].mean()
        by_type = d.groupby("Vehicle_Type",as_index=False)["Automobile_Sales"].mean()
        ad = d.groupby("Vehicle_Type",as_index=False)["Advertising_Expenditure"].sum()
        unemp = d.groupby(["unemployment_rate","Vehicle_Type"],as_index=False)["Automobile_Sales"].mean()
        figs = [
            px.line(yearly,x="Year",y="Automobile_Sales",markers=True,title="Average automobile sales during recession years"),
            px.bar(by_type,x="Vehicle_Type",y="Automobile_Sales",title="Average sales by vehicle type during recessions"),
            px.pie(ad,values="Advertising_Expenditure",names="Vehicle_Type",title="Advertising expenditure share by vehicle type"),
            px.bar(unemp,x="unemployment_rate",y="Automobile_Sales",color="Vehicle_Type",barmode="group",title="Effect of unemployment on vehicle sales")]
    else:
        d = df[df["Year"] == input_year]
        yearly = df.groupby("Year",as_index=False)["Automobile_Sales"].mean()
        monthly = d.groupby("Month",as_index=False)["Automobile_Sales"].sum()
        by_type = d.groupby("Vehicle_Type",as_index=False)["Automobile_Sales"].mean()
        ad = d.groupby("Vehicle_Type",as_index=False)["Advertising_Expenditure"].sum()
        figs = [
            px.line(yearly,x="Year",y="Automobile_Sales",markers=True,title="Average automobile sales by year"),
            px.line(monthly,x="Month",y="Automobile_Sales",markers=True,category_orders={"Month":MONTH_ORDER},title=f"Monthly total automobile sales - {input_year}"),
            px.bar(by_type,x="Vehicle_Type",y="Automobile_Sales",title=f"Average sales by vehicle type - {input_year}"),
            px.pie(ad,values="Advertising_Expenditure",names="Vehicle_Type",title=f"Advertising expenditure by vehicle type - {input_year}")]
    for fig in figs: fig.update_layout(margin=dict(l=20,r=20,t=55,b=25),height=400)
    return html.Div([dcc.Graph(figure=fig,style={"width":"50%"}) for fig in figs], style={"display":"flex","flexWrap":"wrap"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT","8051")), debug=False)
