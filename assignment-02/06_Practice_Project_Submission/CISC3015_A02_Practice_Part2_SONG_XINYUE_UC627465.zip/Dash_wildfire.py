"""CISC3015 Assignment 02 - Practice Project Part 2.
Author: SONG XINYUE (UC627465)
AI use disclosure: OpenAI Codex was used to assist with code drafting, debugging, and presentation. The author reviewed the implementation, verified calculations, and accepts responsibility for the submitted work.
"""
from pathlib import Path
import os
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

DATA_FILE = Path(__file__).with_name("Historical_Wildfires.csv")
df = pd.read_csv(DATA_FILE)
MONTH_ORDER = ["January","February","March","April","May","June","July","August","September","October","November","December"]
if df["Month"].dtype == object:
    df["MonthNum"] = df["Month"].map({m:i+1 for i,m in enumerate(MONTH_ORDER)})
else:
    df["MonthNum"] = df["Month"]

app = Dash(__name__)
app.layout = html.Div([
    html.H1("Australia Wildfire Dashboard", style={"textAlign":"center","color":"#503D36","fontSize":28}),
    html.P("Author: SONG XINYUE | Student ID: UC627465", style={"textAlign":"center"}),
    html.Div([
        html.Label("Select Region:"),
        dcc.RadioItems(id="region", options=[{"label":r,"value":r} for r in ["NSW","NT","QL","SA","TA","VI","WA"]], value="NSW", inline=True),
        html.Label("Select Year:", style={"marginLeft":"28px"}),
        dcc.Dropdown(id="year", options=[{"label":str(y),"value":y} for y in range(2005,2021)], value=2005, clearable=False, style={"width":"180px","display":"inline-block"})
    ], style={"padding":"12px","background":"#F4F7FA","borderRadius":"8px"}),
    html.Div([dcc.Graph(id="plot1", style={"width":"50%"}), dcc.Graph(id="plot2", style={"width":"50%"})], style={"display":"flex"}),
    html.P("AI disclosure: OpenAI Codex assisted with drafting and debugging; all calculations and outputs were reviewed by the author.", style={"fontSize":"12px","color":"#555"})
], style={"maxWidth":"1280px","margin":"auto","fontFamily":"Arial"})

@app.callback(Output("plot1","figure"), Output("plot2","figure"), Input("region","value"), Input("year","value"))
def update_dashboard(region, year):
    filtered = df[(df["Region"] == region) & (df["Year"] == year)].copy()
    monthly = filtered.groupby("MonthNum", as_index=False).agg(Estimated_fire_area=("Estimated_fire_area","mean"), Count=("Count","mean"))
    monthly["Month"] = monthly["MonthNum"].map({i+1:m for i,m in enumerate(MONTH_ORDER)})
    fig1 = px.pie(monthly, values="Estimated_fire_area", names="Month", title=f"Monthly average estimated fire area - {region}, {year}")
    fig2 = px.bar(monthly, x="Month", y="Count", category_orders={"Month":MONTH_ORDER}, title=f"Monthly average pixel count - {region}, {year}")
    fig1.update_layout(margin=dict(l=20,r=20,t=60,b=20)); fig2.update_layout(margin=dict(l=20,r=20,t=60,b=20))
    return fig1, fig2

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT","8050")), debug=False)
