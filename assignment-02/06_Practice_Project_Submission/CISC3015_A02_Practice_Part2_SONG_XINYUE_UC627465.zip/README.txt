Run: pip install -r requirements.txt
Then: python Dash_wildfire.py
Open http://127.0.0.1:8050
